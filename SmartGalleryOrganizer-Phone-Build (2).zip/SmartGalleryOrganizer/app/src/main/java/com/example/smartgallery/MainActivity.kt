package com.example.smartgallery

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

private enum class GalleryTab(val label: String) {
    ALL("All"), PHOTOS("Photos"), VIDEOS("Videos"), SCREENSHOTS("Screenshots"), DUPLICATES("Duplicates")
}

private data class MediaFile(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mime: String,
    val size: Long,
    val dateAdded: Long,
    val isVideo: Boolean,
    val isScreenshot: Boolean,
    val hash: String? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 27, 45)
        window.navigationBarColor = android.graphics.Color.rgb(16, 27, 45)
        setContent { SmartGalleryApp() }
    }
}

@Composable
private fun SmartGalleryApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(GalleryTab.ALL) }
    var files by remember { mutableStateOf<List<MediaFile>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var status by remember { mutableStateOf("Allow access to scan your gallery.") }
    var pendingDelete by remember { mutableStateOf<List<Uri>>(emptyList()) }

    fun permissions(): Array<String> = if (Build.VERSION.SDK_INT >= 34) {
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
    } else if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    } else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 34) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
    } else if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    suspend fun scanGallery() {
        scanning = true
        status = "Scanning media on this device…"
        try {
            val scanned = withContext(Dispatchers.IO) { queryMedia(context) }
            val hashed = withContext(Dispatchers.IO) { findDuplicates(context, scanned) }
            files = hashed
            selected = emptySet()
            status = "Found ${hashed.size} media files • ${hashed.count { it.hash != null }} duplicate copies"
        } catch (e: Exception) {
            status = "Could not scan media: ${e.localizedMessage ?: "unknown error"}"
        } finally { scanning = false }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it } || hasAccess()) scope.launch { scanGallery() }
        else status = "Media access was not granted. You can enable it in Android Settings."
    }

    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            Toast.makeText(context, "Selected files deleted", Toast.LENGTH_SHORT).show()
            scope.launch { scanGallery() }
        }
    }

    fun startScan() {
        if (hasAccess()) scope.launch { scanGallery() }
        else permissionLauncher.launch(permissions())
    }

    LaunchedEffect(Unit) { startScan() }

    val duplicates = remember(files) {
        val groups = files.filter { it.hash != null }.groupBy { it.hash }.values.filter { it.size > 1 }
        groups.flatMap { group -> group.sortedBy { it.dateAdded }.drop(1) }
    }
    val visible = remember(files, tab, query, duplicates) {
        val source = when (tab) {
            GalleryTab.ALL -> files
            GalleryTab.PHOTOS -> files.filter { !it.isVideo && !it.isScreenshot }
            GalleryTab.VIDEOS -> files.filter { it.isVideo }
            GalleryTab.SCREENSHOTS -> files.filter { it.isScreenshot }
            GalleryTab.DUPLICATES -> duplicates
        }
        source.filter { it.name.contains(query, ignoreCase = true) }
    }
    val totalBytes = files.sumOf { it.size }
    val selectedBytes = duplicates.filter { it.uri in selected }.sumOf { it.size }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF356FD2), secondary = Color(0xFF2B9274),
            background = Color(0xFFF5F7FB), surface = Color.White,
            error = Color(0xFFB83F50)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF5F7FB),
            topBar = {
                Column(Modifier.fillMaxWidth().background(Color(0xFF101B2D)).padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Collections, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Smart Gallery", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Your media, organized.", color = Color(0xFFB8C7DC), fontSize = 12.sp)
                        }
                        IconButton(onClick = { startScan() }, enabled = !scanning) {
                            Icon(Icons.Default.Refresh, "Rescan", tint = Color.White)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search files…") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                            focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent
                        )
                    )
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == GalleryTab.ALL, onClick = { tab = GalleryTab.ALL },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == GalleryTab.PHOTOS, onClick = { tab = GalleryTab.PHOTOS },
                        icon = { Icon(Icons.Default.Image, null) }, label = { Text("Photos") })
                    NavigationBarItem(selected = tab == GalleryTab.DUPLICATES, onClick = { tab = GalleryTab.DUPLICATES },
                        icon = { Icon(Icons.Default.ContentCopy, null) }, label = { Text("Duplicates") })
                    NavigationBarItem(selected = tab == GalleryTab.SCREENSHOTS, onClick = { tab = GalleryTab.SCREENSHOTS },
                        icon = { Icon(Icons.Default.Folder, null) }, label = { Text("Folders") })
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                Column(Modifier.padding(16.dp)) {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1D304B))) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("PHONE GALLERY", color = Color(0xFFB9C9DF), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Text("${files.size} files", color = Color.White, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(if (files.isEmpty()) "Ready to organize" else formatBytes(totalBytes),
                                color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text(status, color = Color(0xFFB9C9DF), fontSize = 11.sp)
                            if (scanning) { Spacer(Modifier.height(9.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Your folders", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF18253A))
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FolderTile("Photos", files.count { !it.isVideo && !it.isScreenshot }, Color(0xFFE8EFFB), Color(0xFF356FD2), Modifier.weight(1f)) { tab = GalleryTab.PHOTOS }
                        FolderTile("Videos", files.count { it.isVideo }, Color(0xFFE7F4EE), Color(0xFF26865F), Modifier.weight(1f)) { tab = GalleryTab.VIDEOS }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FolderTile("Screenshots", files.count { it.isScreenshot }, Color(0xFFFFF2DF), Color(0xFFB57A22), Modifier.weight(1f)) { tab = GalleryTab.SCREENSHOTS }
                        FolderTile("Duplicates", duplicates.size, Color(0xFFFBEAEC), Color(0xFFB84F5D), Modifier.weight(1f)) { tab = GalleryTab.DUPLICATES }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tab.label, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("${visible.size} items", color = Color.Gray, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    ScrollableTabRow(selectedTabIndex = tab.ordinal, edgePadding = 0.dp, containerColor = Color.Transparent) {
                        GalleryTab.values().forEach { item ->
                            Tab(selected = tab == item, onClick = { tab = item }, text = { Text(item.label) })
                        }
                    }
                }

                if (tab == GalleryTab.DUPLICATES && duplicates.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${selected.size} selected • ${formatBytes(selectedBytes)}", modifier = Modifier.weight(1f), fontSize = 12.sp, color = Color.Gray)
                        TextButton(onClick = { selected = if (selected.size == duplicates.size) emptySet() else duplicates.map { it.uri }.toSet() }) {
                            Text(if (selected.size == duplicates.size) "Clear" else "Select all")
                        }
                    }
                }

                if (visible.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
                            Icon(if (tab == GalleryTab.DUPLICATES) Icons.Default.CheckCircle else Icons.Default.PhotoLibrary,
                                null, tint = Color(0xFF8B9AB0), modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(10.dp))
                            Text(if (files.isEmpty()) "No media loaded yet" else if (tab == GalleryTab.DUPLICATES) "No duplicates found" else "Nothing in this folder",
                                fontWeight = FontWeight.SemiBold)
                            Text(if (files.isEmpty()) "Grant media permission, then tap rescan." else "Try another folder or search term.",
                                color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(visible, key = { it.uri.toString() }) { file ->
                            MediaCard(file, isDuplicate = tab == GalleryTab.DUPLICATES,
                                selected = file.uri in selected,
                                onSelect = { selected = if (file.uri in selected) selected - file.uri else selected + file.uri })
                        }
                    }
                }
                if (tab == GalleryTab.DUPLICATES && selected.isNotEmpty()) {
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= 30) {
                                val request = MediaStore.createDeleteRequest(context.contentResolver, selected.toList())
                                deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                            } else {
                                Toast.makeText(context, "Deletion approval requires Android 11 or newer in this build.", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB83F50))
                    ) {
                        Icon(Icons.Default.Delete, null); Spacer(Modifier.width(8.dp))
                        Text("Delete selected duplicates")
                    }
                }
            }
        }
    }
}

@Composable
private fun FolderTile(title: String, count: Int, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = bg)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("$count files", color = fg.copy(alpha = .8f), fontSize = 11.sp)
            }
            Icon(when (title) {
                "Photos" -> Icons.Default.Image
                "Videos" -> Icons.Default.Videocam
                "Screenshots" -> Icons.Default.PhoneAndroid
                else -> Icons.Default.ContentCopy
            }, null, tint = fg, modifier = Modifier.size(25.dp))
        }
    }
}

@Composable
private fun MediaCard(file: MediaFile, isDuplicate: Boolean, selected: Boolean, onSelect: () -> Unit) {
    val context = LocalContext.current
    var bitmap by remember(file.uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(file.uri) {
        bitmap = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(file.uri, android.util.Size(500, 500), null)
                else null
            } catch (_: Exception) { null }
        }
    }
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth().then(if (isDuplicate) Modifier.clickable { onSelect() } else Modifier)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(132.dp).background(Color(0xFFE9EEF5))) {
                if (bitmap != null) {
                    Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Icon(if (file.isVideo) Icons.Default.PlayCircle else Icons.Default.Image,
                        null, tint = Color(0xFF8798AE), modifier = Modifier.align(Alignment.Center).size(42.dp))
                }
                if (file.isVideo) {
                    Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(30.dp))
                }
                if (isDuplicate) {
                    Checkbox(checked = selected, onCheckedChange = { onSelect() },
                        modifier = Modifier.align(Alignment.TopEnd))
                }
            }
            Column(Modifier.padding(10.dp)) {
                Text(file.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${if (file.isVideo) "Video" else if (file.isScreenshot) "Screenshot" else "Photo"} • ${formatBytes(file.size)}",
                    color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}

private fun queryMedia(context: android.content.Context): List<MediaFile> {
    val resolver = context.contentResolver
    val result = mutableListOf<MediaFile>()
    val collections = listOf(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI to false,
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true
    )
    for ((collection, video) in collections) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH
        )
        resolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val name = cursor.getString(nameCol) ?: "Untitled"
                val path = if (pathCol >= 0) cursor.getString(pathCol).orEmpty() else ""
                val uri = ContentUris.withAppendedId(collection, id)
                result += MediaFile(id, uri, name, cursor.getString(mimeCol) ?: "", cursor.getLong(sizeCol),
                    cursor.getLong(dateCol), video,
                    path.contains("screenshot", true) || name.contains("screenshot", true) || name.startsWith("screen_", true))
            }
        }
    }
    return result
}

private fun findDuplicates(context: android.content.Context, media: List<MediaFile>): List<MediaFile> {
    // Hash only files with a matching size. The oldest item in each identical-content group is kept.
    val bySize = media.filter { it.size > 0 }.groupBy { it.size }.filterValues { it.size > 1 }
    val hashes = mutableMapOf<Uri, String>()
    for (group in bySize.values) {
        for (item in group) {
            try {
                val digest = MessageDigest.getInstance("SHA-256")
                context.contentResolver.openInputStream(item.uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        digest.update(buffer, 0, read)
                    }
                }
                hashes[item.uri] = digest.digest().joinToString("") { "%02x".format(it) }
            } catch (_: Exception) { }
        }
    }
    return media.map { it.copy(hash = hashes[it.uri]) }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024 * 1024 -> String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024))
    bytes >= 1024L * 1024 -> String.format("%.1f MB", bytes / (1024.0 * 1024))
    bytes >= 1024 -> String.format("%.0f KB", bytes / 1024.0)
    else -> "$bytes B"
}
