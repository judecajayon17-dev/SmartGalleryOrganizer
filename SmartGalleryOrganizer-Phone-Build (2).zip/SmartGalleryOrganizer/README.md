# Smart Gallery Organizer (Android)

A native Kotlin + Jetpack Compose starter app for organizing local Android media.

## Included
- Reads photos and videos from Android MediaStore after permission is granted.
- Separates Photos, Videos, Screenshots, and Duplicates.
- Search by file name.
- Duplicate detection uses SHA-256 content hashes, preceded by a file-size match to reduce unnecessary reads.
- Duplicate review keeps the oldest item in each identical-content group and lets the user select copies for deletion.
- On Android 11+, deletion is submitted through Android's system-approved MediaStore delete request.

## Build an APK
1. Open this folder in Android Studio (Giraffe or newer; current stable recommended).
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android phone.

Command line (with Android SDK and Gradle available):
`gradle assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important notes
- This package is source code, not a precompiled APK. The current build environment has Java but no Android SDK/Gradle installation, so an APK could not be compiled here.
- Android 14+ may grant access only to user-selected photos/videos. The app scans whatever Android permission exposes.
- Screenshot classification uses the media folder path and filename. Some manufacturers use different naming conventions.
- Duplicate detection is exact-file matching, not visual similarity. Edited, resized, recompressed, or visually similar files are not considered duplicates.
- The app does not upload media. Scanning and hashing happen on-device.
- Deletion requires Android's system confirmation UI. Review the selected items before approving.
